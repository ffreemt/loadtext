# SPDX-FileCopyrightText: 2024-present ffreemt <yucongo+fmt@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
